---
title: Register over reelle rettighetshavere
description: Beskrivelser av API innen domene Reelle rettighetshavere
weight: 1
---

# Om registeret
