{
	"id": "9fb88714-6768-4099-977a-2cb28ca37c66",
	"name": "TT02 - RR0004 - UNDER ARBEID - Skade - AS",
	"values": [
		{
			"key": "altinn_schema_base_url",
			"value": "https://brg.apps.tt02.altinn.no",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "jsrsasign-js",
			"value": "",
			"type": "any",
			"enabled": true
		},
		{
			"key": "jwt_signed",
			"value": "",
			"type": "any",
			"enabled": true
		},
		{
			"key": "maskinporten_access_token",
			"value": "",
			"type": "any",
			"enabled": true
		},
		{
			"key": "maskinporten_jwt_fromwebpage",
			"value": "{\"keys\":[{\"p\":\"9mD6V_fkw6yUOZ4Ho85TzzsN2CqbhDaN0eGoXaw6Lp_WdQIej02PhMQQoZYksOHDRCK2ZxrEQY6RfCLT6E-F5Fc-oiqrBJ-SX4nOGkNxn21ucQBGH9pKlHk3Kr8OX5Yde4XD4O05Md_pivIwy8hiTMR5qxO_RDEpaiAxZarSN98\",\"kty\":\"RSA\",\"q\":\"2MvzDapVo2OxqZd6X9n_ZtCZlTm0sFjoXDZBPJH9LqFtQM02HbiUkURInXCkSYl4-CoRxC3TVelRAAT3m3DWxERKGK2NnJtM6bLRss1RvUK0tWqcKNCKzmEBTUq3LYQ2hWLvFR2I1G1A09J7H8a1la_eK1QWkIA0cTksHEDw-ac\",\"d\":\"MfBwKhOfn9Qma-6lynC0Qoojgupg91alz429X-Od7CckLAYFxv8k2-usAnkjD-6B8JJZs3M5dysAQVDyhRizT9CKbpWSoJxJFfH0Qt9FiCk3HeF6KA1TJG_sNGB6KRvvsBw9V7o7U4DOpNs5jlkn-cGZNHrbZzT6_8_DsYBYRcsBa7LUq1731i16Sa1E-uNZw4TWZJkJ2dqzeA_ke9HUikDJqvHAeUFhFdw5twPu-7AUy94KaWe4QDQx5U9wB7HRT43uu8EJmuTI-qLRnaiBZUr0SAxysAGL-g9HvpdU42vgDjUoyzbefZd_2P74qf1PBMOM2P-bi_K1qDfMQkEQuQ\",\"e\":\"AQAB\",\"use\":\"sig\",\"kid\":\"aarsregnskap-test\",\"qi\":\"8jhiUA8tuRPHkV0pqu7ezPFo-vkTd9brO8IPq7tDZcrFK7FkjCmwwkuRH_OzXF-gq8ZxfVGfbB--nJUkosNW4Gm0jQAeh6frObvQM0Sp4qPSLN76fEDghrWkPMcSd6UX5VoBUL08BSk7wzyS7GKs1_KAfsfstYWbjAdTqC23QJg\",\"dp\":\"L30Rw9LsLSsehtyG7HPgg5kGWhwcTaeWPlYYdbW0oTf9xh_adBSnDRgdfIfMGqvpT0DBl635Fgm80QiFf8mULScD044V2JZJSFDvgPBu_iPBndZHrewNZADZOUwKITJ2DFEEKF6RH6PhB_8WmLDPAaz9JpRv0V0IdoQuAUKjslE\",\"alg\":\"RS256\",\"dq\":\"aP79i9S-_Q6_cJ9ISTvPEgBdIYR9Ghs1DdPI7IjX0cmknAnG98X5ThGACaAQMP0_dREK4bQ_8g-5hwTg1otjuFJKgIEtYHdmXJiaLrp5p-uykVo8nxfA4grhEonpBUZPEXLEz7kqF5eCGhSKRO177C7srpdfBkTRITTLRDO_gWk\",\"n\":\"0KYcC_Fnn_e--zgjI5YXv_-TldGElNWvFln4-emSpnv5ZJn2WuLqNqYjrbL-SZjznTv_cR1b22KIT-x6b3zKpB1IWZDYkrv42wCn-1t_hHe2vWPp1FGF40LTYp5IbDR_wYZW9DW1_98iIvS2jT9T92iYmJAji--3OXW5-VeJz46CjANvdjkEzS94l1MOI0E8ntcUw3OHnNIVuS3c4_AEkmXiMlpQLZGAuOPleySZqoKVeR8YcN9tjnqwiRXspOBIJPigXjT_CbBx3WiLbt4tWx1Ej6YsBCyzCzwOYOgsoS3F3RDzHEfH5nIKLAZk7qoZIOxQKfTIcgP1UD_pCIpZeQ\",\"exp\":1749713122}],\"created\":\"2024-06-17 09:25:23\",\"last_updated\":\"2024-06-17 09:25:23\"}",
			"type": "default",
			"enabled": true
		},
		{
			"key": "maskinporten_jwt_signed",
			"value": "",
			"type": "default",
			"enabled": true
		},
		{
			"key": "altinn_access_token",
			"value": "",
			"type": "any",
			"enabled": true
		},
		{
			"key": "altinn_scopes",
			"value": "altinn:instances.read,altinn:instances.write,altinn:serviceowner/instances.read,altinn:serviceowner/instances.write",
			"type": "default",
			"enabled": true
		},
		{
			"key": "boundary",
			"value": "--------------------------078762452006275937278664",
			"type": "default",
			"enabled": true
		},
		{
			"key": "klientId",
			"value": "b0953059-7890-49d3-8bf7-b1eb28becd53",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "schema_type",
			"value": "aarsregnskap-skade-202404",
			"type": "default",
			"enabled": true
		},
		{
			"key": "hovedskjema_innhold",
			"value": "<melding xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://schema.brreg.no/regnsys/aarsregnskap_skade\" dataFormatId=\"3238\" dataFormatVersion=\"50380\" tjenestehandling=\"aarsregnskap_skade\" tjeneste=\"regnskap\">\n<Innsender>\n<enhet>\n<organisasjonsnummer orid=\"18\">312999358</organisasjonsnummer>\n<organisasjonsform orid=\"756\">AS</organisasjonsform>\n<navn orid=\"1\">AKROBATISK POSSESSIV TIGER AS</navn>\n</enhet>\n<opplysningerInnsending>\n<landTilLand orid=\"35172\">false</landTilLand>\n<systemNavn orid=\"39007\">Altinn</systemNavn>\n</opplysningerInnsending>\n</Innsender>\n<Skjemainnhold>\n<regnskapsperiode>\n<regnskapsaar orid=\"17102\">2024</regnskapsaar>\n<regnskapsstart orid=\"17103\">2024-01-01</regnskapsstart>\n<regnskapsslutt orid=\"17104\">2024-12-31</regnskapsslutt>\n</regnskapsperiode>\n<fastsettelse>\n<fastsettelsesdato orid=\"17105\">2025-08-14</fastsettelsesdato>\n<bekreftendeSelskapsrepresentant orid=\"19023\">test</bekreftendeSelskapsrepresentant>\n</fastsettelse>\n<regnskapsprinsipper>\n<smaaForetak orid=\"8079\">nei</smaaForetak>\n<regnskapsreglerSelskap orid=\"25021\">ja</regnskapsreglerSelskap>\n</regnskapsprinsipper>\n<konsern>\n<morselskap orid=\"4168\">nei</morselskap>\n</konsern>\n<aarsberetning>\n<inkludererBerekraftrapportering orid=\"40309\">nei</inkludererBerekraftrapportering>\n</aarsberetning>\n</Skjemainnhold>\n</melding>",
			"type": "default",
			"enabled": true
		},
		{
			"key": "selskapsregnskap_innhold",
			"value": "<melding xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://schema.brreg.no/regnsys/aarsregnskap_skade/underskjema\" dataFormatId=\"760\" dataFormatVersion=\"50520\" tjenestehandling=\"aarsregnskap_skade_underskjema\" tjeneste=\"regnskap\">\n<Rapport-RR0004U>\n<aarsregnskap>\n<regnskapstype orid=\"25942\">S</regnskapstype>\n<valuta orid=\"34984\">NOK</valuta>\n<valoer orid=\"28974\">H</valoer>\n</aarsregnskap>\n</Rapport-RR0004U>\n<Skjemainnhold-RR0004U>\n<resultatregnskapAndreResultatkomponenter>\n<andreInntekterKostnaderInvesteringerRentebaerendeVerdipapirer>\n<aarets orid=\"39049\">200</aarets>\n</andreInntekterKostnaderInvesteringerRentebaerendeVerdipapirer>\n<totalresultat>\n<aarets orid=\"32217\">200</aarets>\n</totalresultat>\n</resultatregnskapAndreResultatkomponenter>\n<balanseForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<forskuddsbetalteDirekteSalgskostnader>\n<aarets orid=\"9885\">400</aarets>\n</forskuddsbetalteDirekteSalgskostnader>\n<sumForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<aarets orid=\"9769\">400</aarets>\n</sumForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<sumEiendeler>\n<aarets orid=\"219\">400</aarets>\n</sumEiendeler>\n</balanseForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<balansePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<andrePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<aarets orid=\"9838\">5000</aarets>\n</andrePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<sumPaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<aarets orid=\"9839\">5000</aarets>\n</sumPaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<egenkapitalForpliktelser>\n<aarets orid=\"32420\">5000</aarets>\n</egenkapitalForpliktelser>\n</balansePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n</Skjemainnhold-RR0004U>\n</melding>",
			"type": "default",
			"enabled": true
		},
		{
			"key": "konsernregnskap_innhold",
			"value": "<melding xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://schema.brreg.no/regnsys/aarsregnskap_skade/underskjema\" dataFormatId=\"760\" dataFormatVersion=\"50520\" tjenestehandling=\"aarsregnskap_skade_underskjema\" tjeneste=\"regnskap\">\n<Rapport-RR0004U>\n<aarsregnskap>\n<regnskapstype orid=\"25942\">K</regnskapstype>\n<valuta orid=\"34984\">NOK</valuta>\n<valoer orid=\"28974\">H</valoer>\n</aarsregnskap>\n</Rapport-RR0004U>\n<Skjemainnhold-RR0004U>\n<resultatregnskapAndreResultatkomponenter>\n<andreInntekterKostnaderInvesteringerRentebaerendeVerdipapirer>\n<aarets orid=\"39049\">200</aarets>\n</andreInntekterKostnaderInvesteringerRentebaerendeVerdipapirer>\n<totalresultat>\n<aarets orid=\"32217\">200</aarets>\n</totalresultat>\n</resultatregnskapAndreResultatkomponenter>\n<balanseForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<forskuddsbetalteDirekteSalgskostnader>\n<aarets orid=\"9885\">400</aarets>\n</forskuddsbetalteDirekteSalgskostnader>\n<sumForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<aarets orid=\"9769\">400</aarets>\n</sumForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<sumEiendeler>\n<aarets orid=\"219\">400</aarets>\n</sumEiendeler>\n</balanseForskuddsbetalteKostnaderOpptjenteIkkeMottatteInntekter>\n<balansePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<andrePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<aarets orid=\"9838\">5000</aarets>\n</andrePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<sumPaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<aarets orid=\"9839\">5000</aarets>\n</sumPaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n<egenkapitalForpliktelser>\n<aarets orid=\"32420\">5000</aarets>\n</egenkapitalForpliktelser>\n</balansePaalopteKostnaderMottatteIkkeOpptjenteInntekter>\n</Skjemainnhold-RR0004U>\n</melding>",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "systemId",
			"value": "ca1b79a2-255f-4614-9f79-f36839344d36",
			"type": "default",
			"enabled": true
		},
		{
			"key": "systembrukerId",
			"value": "312999358_AS",
			"type": "default",
			"enabled": true
		},
		{
			"key": "systemOrgNr",
			"value": "314258916",
			"type": "default",
			"enabled": true
		},
		{
			"key": "systemNavn",
			"value": "Festlig Stille Tiger AS (realistisk eksempel: Fiken/Visma/Maestro etc.)",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "kundeOrgNr",
			"value": "312999358",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "instance_owner_party_id",
			"value": "50745242",
			"type": "default",
			"enabled": true
		},
		{
			"key": "instance_owner_org_number",
			"value": "312999358",
			"type": "default",
			"enabled": true
		},
		{
			"key": "instance_owner_user_id",
			"value": "277416",
			"enabled": true
		},
		{
			"key": "personnummer",
			"value": "07826997170",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "hovedskjema_data_type",
			"value": "Hovedskjema",
			"type": "default",
			"enabled": true
		},
		{
			"key": "underskjema_data_type",
			"value": "Underskjema",
			"type": "default",
			"enabled": true
		},
		{
			"key": "vedlegg_data_type",
			"value": "Vedlegg",
			"type": "default",
			"enabled": true
		},
		{
			"key": "vedlegg_data_type_baerekraft",
			"value": "VedleggBaerekraft",
			"type": "default",
			"enabled": true
		},
		{
			"key": "hovedskjema_upload_type",
			"value": "application/xml",
			"type": "default",
			"enabled": true
		},
		{
			"key": "underskjema_upload_type",
			"value": "application/xml",
			"type": "default",
			"enabled": true
		},
		{
			"key": "",
			"value": "",
			"type": "default",
			"enabled": false
		},
		{
			"key": "skjema_instans_id",
			"value": "",
			"type": "default",
			"enabled": true
		},
		{
			"key": "hovedskjema_data_id",
			"value": "",
			"type": "default",
			"enabled": true
		},
		{
			"key": "underskjema_selskap_data_id",
			"value": "",
			"type": "default",
			"enabled": true
		},
		{
			"key": "underskjema_konsern_data_id",
			"value": "",
			"type": "default",
			"enabled": true
		},
		{
			"key": "vedlegg_data_id",
			"value": "Vedlegg",
			"enabled": true
		},
		{
			"key": "vedlegg_data_id_baerekraft",
			"value": "",
			"type": "any",
			"enabled": true
		}
	],
	"_postman_variable_scope": "environment",
	"_postman_exported_at": "2025-09-03T11:20:49.244Z",
	"_postman_exported_using": "Postman/11.42.5"
}